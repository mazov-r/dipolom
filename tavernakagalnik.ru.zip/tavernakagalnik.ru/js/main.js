document.addEventListener('DOMContentLoaded', function () {
    // кнопка для скролла вверх страницы
    const $floatButton = document.querySelector('.topbutton');
    function scrollButtonToggle() {
        $floatButton.style.display = window.scrollY > 400 ? 'block' : 'none';
    };
    addEventListener('scroll', function (e) {
        scrollButtonToggle();
    });
    scrollButtonToggle();

    // модалка 18+
    const $modal18year = new bootstrap.Modal('#18year', {
        keyboard: false,
        backdrop: 'static',
    });
    $modal18year.show();
    const $noBtn = document.querySelector('#noBtn');
    $noBtn.addEventListener('click', function (e) {
        window.location.href = 'https://ria.ru/20181214/1547986997.html';
    });
    const $yesBtn = document.querySelector('#yesBtn');
    $yesBtn.addEventListener('click', function (e) {
        $modal18year.hide();
    });

    // обратная связь
    const $feedbackModal = new bootstrap.Modal('#feedbackModal');

    const $feedbackModalMessage = document.querySelector('#feedbackModalMessage');
    const $feedbackModalOk = document.querySelector('#feedbackModalOk');
    $feedbackModalOk.addEventListener('click', function (e) {
        $feedbackModal.hide();
    });

    const $form = document.querySelector('#feedbackForm');
    $form.addEventListener('submit', function (e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const xhr = new XMLHttpRequest();
        xhr.open('POST', './send.php', true);
        xhr.onload = function() {
            const result = JSON.parse(xhr.response);
            $feedbackModalMessage.innerText = result.message;
            $feedbackModal.show();
        };
        xhr.send(formData);
    });
});
